from PIL import Image

def jpg_png(image):
    img = Image.open(image)
    img.save("new.png",'png')

jpg2png("C:\\Users\\Dell\\OneDrive\\Desktop\\Picture.jpg")